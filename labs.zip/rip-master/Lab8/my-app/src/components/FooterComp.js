function FooterComp() {
    return (
        <div style={{bottom: '20px', position: 'absolute'}}>
            <hr></hr>
            <i>Группа:</i> ИУ5-52Б
            <br></br>
            <i>Студент:</i> Бабин Артём Сергеевич
        </div>
    );
}

export default FooterComp;