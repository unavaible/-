class Detail:
    def __init__(self, id, name, material, man_id):
        self.id = id
        self.name = name
        self.material = material
        self.man_id = man_id
