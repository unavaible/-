class DetailsMan:
    def __init__(self, detail_id, man_id):
        self.detail_id = detail_id
        self.man_id = man_id
