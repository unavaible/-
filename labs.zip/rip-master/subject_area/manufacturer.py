class Manufacturer:
    def __init__ (self, id, name, country):
        self.id = id
        self.name = name
        self.country = country